<?php
/**
 * Configuración y Conexión PDO a la Base de Datos
 * Turbogram - Plataforma Web SMM
 * Detección inteligente de entorno (Localhost / Servidor Producción)
 */

$is_local = (
    (isset($_SERVER['HTTP_HOST']) && ($_SERVER['HTTP_HOST'] === 'localhost' || strpos($_SERVER['HTTP_HOST'], '127.0.0.1') !== false)) ||
    (isset($_SERVER['SERVER_NAME']) && ($_SERVER['SERVER_NAME'] === 'localhost' || strpos($_SERVER['SERVER_NAME'], '127.0.0.1') !== false)) ||
    (php_sapi_name() === 'cli' && file_exists('c:/xampp'))
);

if ($is_local) {
    // Entorno Local (XAMPP Windows)
    define('DB_HOST', 'localhost');
    define('DB_NAME', 'turbogram_db');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_CHARSET', 'utf8mb4');
} else {
    // Servidor de Producción (Hostinger)
    define('DB_HOST', 'localhost');
    define('DB_NAME', 'u906017405_turbogram');
    define('DB_USER', 'u906017405_userturbogram');
    define('DB_PASS', 'W_2N33s!zN*YVNJ');
    define('DB_CHARSET', 'utf8mb4');
}

class Database {
    private static ?PDO $instance = null;

    public static function getConnection(): PDO {
        if (self::$instance === null) {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];
            try {
                self::$instance = new PDO($dsn, DB_USER, DB_PASS, $options);
            } catch (PDOException $e) {
                die("Error de conexión a la base de datos: " . $e->getMessage());
            }
        }
        return self::$instance;
    }
}
